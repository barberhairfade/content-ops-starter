# Next.js Backlink Project

This is a minimal Next.js project that contains a page with backlinks to your site.

## Files included
- `pages/index.js` — main page with backlinks
- `pages/_app.js` — global app wrapper
- `styles/globals.css` — basic styling
- `public/` — place any assets here

## Usage

1. Install dependencies:
```bash
npm install
```

2. Run development server:
```bash
npm run dev
# Open http://localhost:3000
```

3. To build for production:
```bash
npm run build
npm start
```

## Deploying to Netlify (brief)
Netlify supports Next.js builds using its build system or by connecting a Git repository.
- Connect your repo at Netlify and set build command: `npm run build` and publish directory: `.next` (Netlify automatically handles builds for supported frameworks).
- Alternatively use Vercel (recommended for Next.js) for easiest deployment.

This project is created to host a page that points to:
- https://barberhairfade.com/low-fade-haircut/
- https://barberhairfade.com/face-shape-detector/

Customize the links in `pages/index.js` as needed.
