import Head from 'next/head'
import Link from 'next/link'
import styles from '../styles/Home.module.css'

export default function Home() {
  return (
    <>
      <Head>
        <title>Backlink Page — BarberHairFade</title>
        <meta name="description" content="Backlink page for BarberHairFade - Low Fade Haircut & Face Shape Analyzer" />
        <meta name="robots" content="index,follow" />
      </Head>

      <main className={styles.main}>
        <h1 className={styles.title}>BarberHairFade Backlink Page</h1>

        <p className={styles.description}>
          Useful resources and links:
        </p>

        <div className={styles.grid}>
          <a href="https://barberhairfade.com/low-fade-haircut/" target="_blank" rel="noopener noreferrer" className={styles.card}>
            <h3>Low Fade Haircut &rarr;</h3>
            <p>Complete guide to low fade haircuts for men.</p>
          </a>

          <a href="https://barberhairfade.com/face-shape-detector/" target="_blank" rel="noopener noreferrer" className={styles.card}>
            <h3>Face Shape Analyzer &rarr;</h3>
            <p>Find the best hairstyles for your face shape.</p>
          </a>
        </div>

        <footer className={styles.footer}>
          <p>Hosted on Next.js — deploy to Netlify or Vercel.</p>
        </footer>
      </main>
    </>
  )
}
